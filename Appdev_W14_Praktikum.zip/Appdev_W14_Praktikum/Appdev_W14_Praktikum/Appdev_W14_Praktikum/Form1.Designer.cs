﻿namespace Appdev_W14_Praktikum
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.btn_add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.tBox_minute = new System.Windows.Forms.TextBox();
            this.cBox_teamHome = new System.Windows.Forms.ComboBox();
            this.cBox_teamAway = new System.Windows.Forms.ComboBox();
            this.cBox_teamChoose = new System.Windows.Forms.ComboBox();
            this.cBox_player = new System.Windows.Forms.ComboBox();
            this.cBox_type = new System.Windows.Forms.ComboBox();
            this.dateMatch = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_data
            // 
            this.dgv_data.AllowUserToAddRows = false;
            this.dgv_data.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_data.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(40, 254);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersVisible = false;
            this.dgv_data.RowHeadersWidth = 82;
            this.dgv_data.RowTemplate.Height = 33;
            this.dgv_data.Size = new System.Drawing.Size(777, 308);
            this.dgv_data.TabIndex = 0;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(861, 514);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(139, 48);
            this.btn_add.TabIndex = 1;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Match ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Team Home";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(562, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Team Away";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(562, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Match Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(857, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Team";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(857, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 25);
            this.label6.TabIndex = 6;
            this.label6.Text = "Minute";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(857, 423);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(857, 371);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Player";
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1023, 514);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(139, 48);
            this.btn_delete.TabIndex = 10;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(420, 634);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(439, 62);
            this.btn_insert.TabIndex = 11;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(185, 57);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(295, 31);
            this.tb_matchID.TabIndex = 12;
            // 
            // tBox_minute
            // 
            this.tBox_minute.Location = new System.Drawing.Point(951, 254);
            this.tBox_minute.Name = "tBox_minute";
            this.tBox_minute.Size = new System.Drawing.Size(240, 31);
            this.tBox_minute.TabIndex = 13;
            // 
            // cBox_teamHome
            // 
            this.cBox_teamHome.FormattingEnabled = true;
            this.cBox_teamHome.Location = new System.Drawing.Point(185, 122);
            this.cBox_teamHome.Name = "cBox_teamHome";
            this.cBox_teamHome.Size = new System.Drawing.Size(295, 33);
            this.cBox_teamHome.TabIndex = 14;
            this.cBox_teamHome.SelectedIndexChanged += new System.EventHandler(this.cBox_teamHome_SelectedIndexChanged);
            // 
            // cBox_teamAway
            // 
            this.cBox_teamAway.FormattingEnabled = true;
            this.cBox_teamAway.Location = new System.Drawing.Point(717, 122);
            this.cBox_teamAway.Name = "cBox_teamAway";
            this.cBox_teamAway.Size = new System.Drawing.Size(359, 33);
            this.cBox_teamAway.TabIndex = 15;
            this.cBox_teamAway.SelectedIndexChanged += new System.EventHandler(this.cBox_teamAway_SelectedIndexChanged);
            // 
            // cBox_teamChoose
            // 
            this.cBox_teamChoose.FormattingEnabled = true;
            this.cBox_teamChoose.Location = new System.Drawing.Point(951, 314);
            this.cBox_teamChoose.Name = "cBox_teamChoose";
            this.cBox_teamChoose.Size = new System.Drawing.Size(240, 33);
            this.cBox_teamChoose.TabIndex = 16;
            this.cBox_teamChoose.SelectedIndexChanged += new System.EventHandler(this.cBox_teamChoose_SelectedIndexChanged);
            // 
            // cBox_player
            // 
            this.cBox_player.FormattingEnabled = true;
            this.cBox_player.Location = new System.Drawing.Point(951, 371);
            this.cBox_player.Name = "cBox_player";
            this.cBox_player.Size = new System.Drawing.Size(240, 33);
            this.cBox_player.TabIndex = 17;
            // 
            // cBox_type
            // 
            this.cBox_type.FormattingEnabled = true;
            this.cBox_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cBox_type.Location = new System.Drawing.Point(951, 423);
            this.cBox_type.Name = "cBox_type";
            this.cBox_type.Size = new System.Drawing.Size(240, 33);
            this.cBox_type.TabIndex = 18;
            // 
            // dateMatch
            // 
            this.dateMatch.Location = new System.Drawing.Point(717, 53);
            this.dateMatch.Name = "dateMatch";
            this.dateMatch.Size = new System.Drawing.Size(359, 31);
            this.dateMatch.TabIndex = 19;
            this.dateMatch.ValueChanged += new System.EventHandler(this.dateMatch_ValueChanged);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1221, 732);
            this.Controls.Add(this.dateMatch);
            this.Controls.Add(this.cBox_type);
            this.Controls.Add(this.cBox_player);
            this.Controls.Add(this.cBox_teamChoose);
            this.Controls.Add(this.cBox_teamAway);
            this.Controls.Add(this.cBox_teamHome);
            this.Controls.Add(this.tBox_minute);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.dgv_data);
            this.Name = "Form_Main";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.TextBox tBox_minute;
        private System.Windows.Forms.ComboBox cBox_teamHome;
        private System.Windows.Forms.ComboBox cBox_teamAway;
        private System.Windows.Forms.ComboBox cBox_teamChoose;
        private System.Windows.Forms.ComboBox cBox_player;
        private System.Windows.Forms.ComboBox cBox_type;
        private System.Windows.Forms.DateTimePicker dateMatch;
    }
}

