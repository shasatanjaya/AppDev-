﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Appdev_W14_Praktikum
{
    public partial class Form_Main : Form
    {
        public Form_Main()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string query;
        DataTable dtTeamHome;
        DataTable dtTeamAway;
        DataTable dtTeamChoose;
        DataTable dtDMatch;
        DataTable dtPlayer;
        DataTable dtTanggal; //buat atur matchid
        DataTable dtTanggalPilih;
        DataTable dtDgv;

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                sqlConnect = new MySqlConnection("server=localhost;uid=root;pwd=Shasa20055;database=premier_league");

                dtTeamHome = new DataTable();
                query = "SELECT * from team;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtTeamHome = new DataTable();
                sqlDataAdapter.Fill(dtTeamHome);

                cBox_teamHome.DataSource = dtTeamHome;
                cBox_teamHome.DisplayMember = "team_name";
                cBox_teamHome.ValueMember = "team_id";
                cBox_teamHome.Text = "";

                dtTeamAway = new DataTable();
                query = "SELECT * from team;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtTeamHome = new DataTable();
                sqlDataAdapter.Fill(dtTeamAway);

                cBox_teamAway.DataSource = dtTeamAway;
                cBox_teamAway.DisplayMember = "team_name";
                cBox_teamAway.ValueMember = "team_id";
                cBox_teamAway.Text = "";



                dtDgv = new DataTable();
                //dtInsert.Columns.Add("Minutes");
                dtDgv.Columns.Add("Team");
                dtDgv.Columns.Add("Player");
                dtDgv.Columns.Add("Type");
                dgv_data.DataSource = dtDgv;

                dtDMatch = new DataTable();
                dtDMatch.Columns.Add("minute");
                dtDMatch.Columns.Add("team_id");
                dtDMatch.Columns.Add("player_id");
                dtDMatch.Columns.Add("type");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cBox_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (cBox_teamAway.Text == cBox_teamHome.Text)
                {
                    MessageBox.Show("Cannot choose the same team!", "ERROR");
                }
                else
                {
                    dtTeamChoose = new DataTable();
                    query = $@"
SELECT team_name, team_id 
FROM team
WHERE team_id = '{cBox_teamAway.SelectedValue}' OR team_id = '{cBox_teamHome.SelectedValue}';";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamChoose);

                    cBox_teamChoose.DataSource = dtTeamChoose;
                    cBox_teamChoose.DisplayMember = "team_name";
                    cBox_teamChoose.ValueMember = "team_id";
                    cBox_teamChoose.Text = "";
                    cBox_type.Text = "";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cBox_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cBox_teamAway.Text == cBox_teamHome.Text)
                {
                    MessageBox.Show("Cannot choose the same team!", "ERROR");
                }
                else
                {
                    dtTeamChoose = new DataTable();
                    query = $@"
SELECT team_name, team_id 
FROM team
WHERE team_id = '{cBox_teamAway.SelectedValue}' OR team_id = '{cBox_teamHome.SelectedValue}';";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeamChoose);

                    cBox_teamChoose.DataSource = dtTeamChoose;
                    cBox_teamChoose.DisplayMember = "team_name";
                    cBox_teamChoose.ValueMember = "team_id";
                    cBox_teamChoose.Text = "";

                    cBox_type.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void cBox_teamChoose_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dtPlayer = new DataTable();
                query = $@"
SELECT player_name, player_id
FROM player p
WHERE team_id = '{cBox_teamChoose.SelectedValue}';";

                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtPlayer);

                cBox_player.DataSource = dtPlayer;
                cBox_player.DisplayMember = "player_name";
                cBox_player.ValueMember = "player_id";
                cBox_player.Text = "";

                cBox_type.Text = "";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        int goalHome = 0;
        int goalAway = 0;
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tBox_minute.Text == "" || cBox_teamChoose.Text == "" || cBox_player.Text == "" || cBox_type.Text == "" || tb_matchID.Text == "")
            {
                MessageBox.Show("Fill all the fields!", "ERROR");
            }
            else
            {
                dtDgv.Rows.Add(cBox_teamChoose.Text, cBox_player.Text, cBox_type.Text);

                if (cBox_type.Text == "GO" || cBox_type.Text == "GP")
                {
                    if (cBox_teamAway.Text == cBox_teamChoose.Text)
                    {
                        goalAway++;
                    }
                    else
                    {
                        goalHome++;
                    }
                }
                else if (cBox_type.Text == "GW")
                {
                    if (cBox_teamAway.Text == cBox_teamChoose.Text)
                    {
                        goalHome++;
                    }
                    else
                    {
                        goalAway++;
                    }
                }

                dtDMatch.Rows.Add(tBox_minute.Text, cBox_teamChoose.SelectedValue, cBox_player.SelectedValue, cBox_type.Text);
                cBox_type.Text = "";
                tBox_minute.Clear();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow view = dgv_data.CurrentRow;
            int indexRemove = 0;

            if (dgv_data.Rows.Count != 0)
            {
                for (int i = 0; i < dtDgv.Rows.Count; i++)
                {
                    if (dtDgv.Rows[i][0].ToString().Contains(view.Cells[0].Value.ToString()))
                    {
                        indexRemove = i;
                    }

                }
                dtDgv.Rows.RemoveAt(indexRemove);
                dtDMatch.Rows.RemoveAt(indexRemove);
            }

            dgv_data.DataSource = dtDgv;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_matchID.Text != "")
                {
                    //DMatch: match_id, minute, team_id, player_id, type, delete
                    //Match: match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, delete

                    for (int i = 0; i < dgv_data.Rows.Count; i++)
                    {
                        query = $@"
INSERT INTO DMatch VALUES 
('{tb_matchID.Text}', '{dtDMatch.Rows[i][0].ToString()}', '{dtDMatch.Rows[i][1].ToString()}', '{dtDMatch.Rows[i][2].ToString()}', '{dtDMatch.Rows[i][3].ToString()}', '0');";

                        sqlConnect.Open();
                        sqlCommand = new MySqlCommand(query, sqlConnect);
                        sqlCommand.ExecuteNonQuery();
                        sqlConnect.Close();
                    }

                    query = $@"
INSERT INTO `match` VALUES 
('{tb_matchID.Text}', '{year}-{month}-{day}', '{cBox_teamHome.SelectedValue}', '{cBox_teamAway.SelectedValue}', '{goalHome.ToString()}', '{goalAway.ToString()}', 'M002', '0');";

                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();

                    cBox_teamAway.Text = "";
                    cBox_teamHome.Text = "";
                    tBox_minute.Text = "";
                    cBox_type.Text = "";
                    cBox_teamChoose.Text = "";
                    cBox_player.Text = "";
                }
                else 
                {
                    MessageBox.Show("Fill all the fields!", "ERROR");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        string day = "";
        string month = "";
        string year = "";
        private void dateMatch_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                query = $@"
SELECT concat(date_format(match_date, '%Y'), date_format(match_date, '%m'), date_format(match_Date, '%d'))
FROM `match`
ORDER BY 1 desc
LIMIT 1;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtTanggal = new DataTable();
                sqlDataAdapter.Fill(dtTanggal);

                day = dateMatch.Value.Day.ToString();
                if (Convert.ToInt32(day) < 10)
                {
                    day = $"0{day}";
                }

                month = dateMatch.Value.Month.ToString();
                if (Convert.ToInt32(month) < 10)
                {
                    month = $"0{month}";
                }

                year = dateMatch.Value.Year.ToString();

                int dateChoose = Convert.ToInt32($"{year}{month}{day}");
                int dateLast = Convert.ToInt32(dtTanggal.Rows[0][0]);


                //MessageBox.Show($"{dateChoose} | {dateLast}");

                if (dateChoose >= Convert.ToInt32(dtTanggal.Rows[0][0]))
                {
                    query = $@"
SELECT match_id FROM `match`
WHERE match_id like '{year}%'
ORDER BY 1 desc
LIMIT 1;";

                    sqlCommand = new MySqlCommand(query, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    dtTanggalPilih = new DataTable();
                    sqlDataAdapter.Fill(dtTanggalPilih);

                    if (dtTanggalPilih.Rows.Count == 0)
                    {
                        tb_matchID.Text = $"{year}001";
                    }
                    else if(dtTanggalPilih.Rows.Count == 1)
                    {
                        int jumlahMatch = Convert.ToInt32(dtTanggalPilih.Rows[0][0]) + 1;
                        tb_matchID.Text = $"{jumlahMatch}";
                    }
                }
                else
                {
                    MessageBox.Show("Date cannot be before the last match date!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
