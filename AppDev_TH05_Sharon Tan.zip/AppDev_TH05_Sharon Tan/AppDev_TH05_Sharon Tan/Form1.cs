﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev_TH05_Sharon_Tan
{
    public partial class MainView : Form
    {
        DataTable dtProduksiSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();

        int currentEdit = 0;
        public MainView()
        {
            InitializeComponent();

            tBox_harga.KeyPress += tBox_harga_KeyPress;
            tBox_stock.KeyPress += tBox_stock_KeyPress;
        }

        public void clearTextBoxProduct()
        {
            tBox_nameProduct.Clear();
            tBox_harga.Clear();
            tBox_stock.Clear();
            cBox_chooseCategory.Text = "";
        }
        public void clearTextBoxCategory()
        {
            tBox_namaCategory.Clear();
        }

        
        private void form_mainView_Load(object sender, EventArgs e)
        {

            dtProduksiSimpan.Columns.Add("ID Produk");
            dtProduksiSimpan.Columns.Add("Nama Produk");
            dtProduksiSimpan.Columns.Add("Harga");
            dtProduksiSimpan.Columns.Add("Stock");
            dtProduksiSimpan.Columns.Add("ID Category");

            dtProdukTampil.Columns.Add("ID Produk");
            dtProdukTampil.Columns.Add("Nama Produk");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtProduksiSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProduksiSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProduksiSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProduksiSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProduksiSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProduksiSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProduksiSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProduksiSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dGV_product.DataSource = dtProduksiSimpan;
            dGV_product.Columns[1].Width = 100;
            dGV_product.Columns[3].Width = 45;
            dGV_product.AutoResizeRows();


            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            dGV_category.DataSource = dtCategory;
            dGV_category.AutoResizeRows();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cBox_chooseCategory.Items.Add(dtCategory.Rows[i][1].ToString());
                cBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
            }
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
        }

        private void btn_addProduct_Click(object sender, EventArgs e)
        {

            string hurufID = "";
            int indexID = 0;
            string finalID = "";

            int count = 0;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString().Contains(cBox_chooseCategory.Text))
                {
                    count++;
                }
            }

            if (tBox_nameProduct.Text == "" || cBox_chooseCategory.Text == "" || tBox_harga.Text == "" || tBox_stock.Text == "")
            {
                MessageBox.Show("Input detail dengan lengkap", "ERROR");
            }
            else if (count != 1)
            {
                MessageBox.Show("Pilih category dulu", "ERROR");
            }
            else
            {

                hurufID = tBox_nameProduct.Text.Substring(0, 1).ToUpper(); //ngambil huruf pertama

                for (int i = 0; i < dtProduksiSimpan.Rows.Count; i++) //ngambil/cek hurufID
                {
                    if (dtProduksiSimpan.Rows[i][0].ToString().Contains(hurufID))
                    {
                        indexID = Convert.ToInt16(dtProduksiSimpan.Rows[i][0].ToString().Substring(1, 3));

                    }
                }

                indexID++;

                if (indexID <= 9)
                {
                    finalID = $"{hurufID}00{indexID}";
                }
                else if (indexID <= 99)
                {
                    finalID = $"{hurufID}0{indexID}";
                }
                else if (indexID <= 999)
                {
                    finalID = $"{hurufID}{indexID}";
                }

                string categoryIDInput = "";

                for (int i = 0; i < dtCategory.Rows.Count; i++) //cek id category
                {
                    if (dtCategory.Rows[i][1].ToString().Contains(cBox_chooseCategory.SelectedItem.ToString()))
                    {
                        categoryIDInput = dtCategory.Rows[i][0].ToString();
                    }
                }
                dtProduksiSimpan.Rows.Add(finalID, tBox_nameProduct.Text, tBox_harga.Text, tBox_stock.Text, categoryIDInput);
                dGV_product.DataSource = dtProduksiSimpan;
            }
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();

            dGV_product.AutoResizeRows();
            clearTextBoxProduct();
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (tBox_namaCategory.Text == dtCategory.Rows[i][1].ToString())
                {
                    count++;
                }
            }

            if (tBox_namaCategory.Text == "")
            {
                MessageBox.Show("Input detail dengan lengkap", "ERROR");
            }
            else if (count > 0)
            {
                MessageBox.Show("Category sudah ada", "ERROR");
            }
            else
            {
                int indexIDCategory = 0;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {

                    indexIDCategory = Convert.ToInt16(dtCategory.Rows[i][0].ToString().Substring(1));

                }
                indexIDCategory++;
                dtCategory.Rows.Add($"C{indexIDCategory}", tBox_namaCategory.Text);

                cBox_chooseCategory.Items.Clear();
                cBox_filter.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    cBox_chooseCategory.Items.Add(dtCategory.Rows[i][1].ToString());
                    cBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }
            }
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            dGV_category.AutoResizeRows();
            clearTextBoxCategory();
        }

        private void dGV_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow view = dGV_product.CurrentRow;

            tBox_nameProduct.Text = view.Cells[1].Value.ToString();
            tBox_harga.Text = view.Cells[2].Value.ToString();
            tBox_stock.Text = view.Cells[3].Value.ToString();

            string currentCategory = "";
            for (int i = 0; i < dtCategory.Rows.Count; i++) //cari category
            {
                if (dGV_product.CurrentRow.Cells[4].Value.ToString().Contains(dtCategory.Rows[i][0].ToString()))
                {
                    currentCategory = dtCategory.Rows[i][1].ToString(); //nama category
                }
            }

            cBox_chooseCategory.Text = currentCategory;
            currentEdit = view.Index;
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (tBox_harga.Text == "" || cBox_chooseCategory.Text == "" || tBox_harga.Text == "" || tBox_stock.Text == "" || dGV_product.Rows.Count == 0)
            {
                MessageBox.Show("Pilih data yang ingin diedit", "ERROR");
            }
            else
            {
                dGV_product.DataSource = dtProduksiSimpan;
                if (dGV_product.Rows.Count != 0)
                {
                    dtProduksiSimpan.Rows[currentEdit][1] = tBox_nameProduct.Text;
                    dtProduksiSimpan.Rows[currentEdit][2] = tBox_harga.Text;
                    dtProduksiSimpan.Rows[currentEdit][3] = tBox_stock.Text;

                    string categoryIDInput = "";
                    for (int i = 0; i < dtCategory.Rows.Count; i++) //cek id category
                    {
                        if (dtCategory.Rows[i][1].ToString().Contains(cBox_chooseCategory.SelectedItem.ToString()))
                        {
                            categoryIDInput = dtCategory.Rows[i][0].ToString();
                        }
                    }
                    dtProduksiSimpan.Rows[currentEdit][4] = categoryIDInput;
                    if (tBox_stock.Text == "0")
                    {
                        dtProduksiSimpan.Rows.RemoveAt(currentEdit);
                    }
                }
            }
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            
            clearTextBoxProduct();

        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (tBox_harga.Text == "" || cBox_chooseCategory.Text == "" || tBox_harga.Text == "" || tBox_stock.Text == ""){}
            else
            {

                DataGridViewRow view = dGV_product.CurrentRow;
                int indexRemove = 0;

                if (dGV_product.Rows.Count != 0)
                {
                    for (int i = 0; i < dtProduksiSimpan.Rows.Count; i++)
                    {
                        if (dtProduksiSimpan.Rows[i][0].ToString().Contains(view.Cells[0].Value.ToString()))
                        {
                            indexRemove = i;
                        }

                    }
                    dtProduksiSimpan.Rows.RemoveAt(indexRemove);

                }
            }
            cBox_filter.Text = "";
            dGV_product.DataSource = dtProduksiSimpan;
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            dGV_product.AutoResizeRows();
            clearTextBoxCategory();
            clearTextBoxProduct();
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            cBox_filter.Text = "";
            if (tBox_namaCategory.Text == ""){}
            else
            {
                int count = 0; //buat cek biar gada yg ketinggalan
                int jumlahBaris = dtProduksiSimpan.Rows.Count;
                DataGridViewRow view = dGV_category.CurrentRow;

                dGV_product.DataSource = dtProduksiSimpan;

                for (int i = 0; i < jumlahBaris; i++)
                {
                    if (count == 0)
                    {
                        if (dtProduksiSimpan.Rows[i][4].ToString().Contains(view.Cells[0].Value.ToString()))
                        {
                            dtProduksiSimpan.Rows.RemoveAt(i);
                            count++;
                        }
                    }
                    else if (count > 0)
                    {
                        if (dtProduksiSimpan.Rows[i - count][4].ToString().Contains(view.Cells[0].Value.ToString()))
                        {
                            dtProduksiSimpan.Rows.RemoveAt(i - count);
                            count++;
                        }
                    }
                }
                if (dGV_category.Rows.Count != 0)
                {
                    dGV_category.Rows.Remove(view);
                }

                cBox_chooseCategory.Items.Clear();
                cBox_filter.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    cBox_chooseCategory.Items.Add(dtCategory.Rows[i][1].ToString());
                    cBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }
            }
            dGV_product.AutoResizeRows();
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            clearTextBoxCategory();
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cBox_filter.Enabled = true;
        }

        private void cBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
             
            dtProdukTampil.Rows.Clear();
            string filterCategory = "";

            for (int i = 0; i < dtCategory.Rows.Count; i++) //nama category -> id category
            {
                if (cBox_filter.Text == dtCategory.Rows[i][1].ToString())
                {
                    filterCategory = dtCategory.Rows[i][0].ToString();
                }
            }

            for (int i = 0; i < dtProduksiSimpan.Rows.Count; i++)
            {
                if (dtProduksiSimpan.Rows[i][4].ToString().Contains(filterCategory))
                {
                    dtProdukTampil.Rows.Add(dtProduksiSimpan.Rows[i][0].ToString(), dtProduksiSimpan.Rows[i][1].ToString(), dtProduksiSimpan.Rows[i][2].ToString(), dtProduksiSimpan.Rows[i][3].ToString(), dtProduksiSimpan.Rows[i][4].ToString());
                }
            }
            dGV_product.DataSource = dtProdukTampil;
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            dGV_product.AutoResizeRows();

        }

        private void btn_showAll_Click(object sender, EventArgs e)
        {
            cBox_filter.Enabled = false;
            cBox_filter.Text = "";
            dGV_product.DataSource = dtProduksiSimpan;
            dGV_category.ClearSelection();
            dGV_product.ClearSelection();
            dGV_product.AutoResizeRows();
        }

        private void dGV_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow view = dGV_category.CurrentRow;
            tBox_namaCategory.Text = view.Cells[1].Value.ToString();
            
        }

        private void tBox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tBox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
