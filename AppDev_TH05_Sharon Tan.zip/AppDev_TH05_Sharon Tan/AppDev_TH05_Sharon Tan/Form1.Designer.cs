﻿namespace AppDev_TH05_Sharon_Tan
{
    partial class MainView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainView));
            this.dGV_product = new System.Windows.Forms.DataGridView();
            this.dGV_category = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBox_namaCategory = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tBox_nameProduct = new System.Windows.Forms.TextBox();
            this.tBox_harga = new System.Windows.Forms.TextBox();
            this.tBox_stock = new System.Windows.Forms.TextBox();
            this.cBox_chooseCategory = new System.Windows.Forms.ComboBox();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.btn_showAll = new System.Windows.Forms.Button();
            this.cBox_filter = new System.Windows.Forms.ComboBox();
            this.btn_filter = new System.Windows.Forms.Button();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dGV_product
            // 
            this.dGV_product.AllowUserToAddRows = false;
            this.dGV_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dGV_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dGV_product.Location = new System.Drawing.Point(62, 125);
            this.dGV_product.Name = "dGV_product";
            this.dGV_product.RowHeadersVisible = false;
            this.dGV_product.RowHeadersWidth = 82;
            this.dGV_product.RowTemplate.Height = 33;
            this.dGV_product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_product.Size = new System.Drawing.Size(644, 451);
            this.dGV_product.TabIndex = 0;
            this.dGV_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_product_CellClick);
            // 
            // dGV_category
            // 
            this.dGV_category.AllowUserToAddRows = false;
            this.dGV_category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dGV_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dGV_category.Location = new System.Drawing.Point(781, 125);
            this.dGV_category.Name = "dGV_category";
            this.dGV_category.RowHeadersVisible = false;
            this.dGV_category.RowHeadersWidth = 82;
            this.dGV_category.RowTemplate.Height = 33;
            this.dGV_category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_category.Size = new System.Drawing.Size(376, 271);
            this.dGV_category.TabIndex = 1;
            this.dGV_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_category_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 50);
            this.label1.TabIndex = 2;
            this.label1.Text = "Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(772, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 50);
            this.label2.TabIndex = 3;
            this.label2.Text = "Category";
            // 
            // tBox_namaCategory
            // 
            this.tBox_namaCategory.Location = new System.Drawing.Point(897, 430);
            this.tBox_namaCategory.Name = "tBox_namaCategory";
            this.tBox_namaCategory.Size = new System.Drawing.Size(260, 31);
            this.tBox_namaCategory.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(53, 609);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 50);
            this.label3.TabIndex = 5;
            this.label3.Text = "Detail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(776, 436);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Nama:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 681);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Nama:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 767);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Harga:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 723);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 25);
            this.label7.TabIndex = 9;
            this.label7.Text = "Category:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(57, 819);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 25);
            this.label8.TabIndex = 10;
            this.label8.Text = "Stock:";
            // 
            // tBox_nameProduct
            // 
            this.tBox_nameProduct.Location = new System.Drawing.Point(175, 681);
            this.tBox_nameProduct.Name = "tBox_nameProduct";
            this.tBox_nameProduct.Size = new System.Drawing.Size(531, 31);
            this.tBox_nameProduct.TabIndex = 11;
            // 
            // tBox_harga
            // 
            this.tBox_harga.Location = new System.Drawing.Point(175, 767);
            this.tBox_harga.Name = "tBox_harga";
            this.tBox_harga.Size = new System.Drawing.Size(169, 31);
            this.tBox_harga.TabIndex = 12;
            this.tBox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_harga_KeyPress);
            // 
            // tBox_stock
            // 
            this.tBox_stock.Location = new System.Drawing.Point(175, 813);
            this.tBox_stock.Name = "tBox_stock";
            this.tBox_stock.Size = new System.Drawing.Size(169, 31);
            this.tBox_stock.TabIndex = 13;
            this.tBox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_stock_KeyPress);
            // 
            // cBox_chooseCategory
            // 
            this.cBox_chooseCategory.FormattingEnabled = true;
            this.cBox_chooseCategory.Location = new System.Drawing.Point(175, 723);
            this.cBox_chooseCategory.Name = "cBox_chooseCategory";
            this.cBox_chooseCategory.Size = new System.Drawing.Size(169, 33);
            this.cBox_chooseCategory.TabIndex = 14;
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.Chartreuse;
            this.btn_addProduct.Location = new System.Drawing.Point(364, 755);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(110, 89);
            this.btn_addProduct.TabIndex = 15;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Gold;
            this.btn_EditProduct.Location = new System.Drawing.Point(480, 755);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(110, 89);
            this.btn_EditProduct.TabIndex = 16;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_removeProduct.Location = new System.Drawing.Point(596, 755);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(110, 89);
            this.btn_removeProduct.TabIndex = 17;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // btn_showAll
            // 
            this.btn_showAll.Location = new System.Drawing.Point(310, 68);
            this.btn_showAll.Name = "btn_showAll";
            this.btn_showAll.Size = new System.Drawing.Size(94, 38);
            this.btn_showAll.TabIndex = 18;
            this.btn_showAll.Text = "All";
            this.btn_showAll.UseVisualStyleBackColor = true;
            this.btn_showAll.Click += new System.EventHandler(this.btn_showAll_Click);
            // 
            // cBox_filter
            // 
            this.cBox_filter.Enabled = false;
            this.cBox_filter.FormattingEnabled = true;
            this.cBox_filter.Location = new System.Drawing.Point(515, 67);
            this.cBox_filter.Name = "cBox_filter";
            this.cBox_filter.Size = new System.Drawing.Size(191, 33);
            this.cBox_filter.TabIndex = 20;
            this.cBox_filter.SelectedIndexChanged += new System.EventHandler(this.cBox_filter_SelectedIndexChanged);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(410, 68);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(94, 40);
            this.btn_filter.TabIndex = 21;
            this.btn_filter.Text = "Filter:";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.Chartreuse;
            this.btn_addCategory.Location = new System.Drawing.Point(913, 478);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(119, 89);
            this.btn_addCategory.TabIndex = 22;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_removeCategory.Location = new System.Drawing.Point(1038, 478);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(119, 89);
            this.btn_removeCategory.TabIndex = 23;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(819, 609);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(120, 103);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AppDev_TH05_Sharon_Tan.Properties.Resources._12830006_middle_removebg_preview1;
            this.pictureBox1.Location = new System.Drawing.Point(763, 573);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(588, 371);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // MainView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1217, 905);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.cBox_filter);
            this.Controls.Add(this.btn_showAll);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.cBox_chooseCategory);
            this.Controls.Add(this.tBox_stock);
            this.Controls.Add(this.tBox_harga);
            this.Controls.Add(this.tBox_nameProduct);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tBox_namaCategory);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dGV_category);
            this.Controls.Add(this.dGV_product);
            this.Name = "MainView";
            this.Text = "Mew Shop";
            this.Load += new System.EventHandler(this.form_mainView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGV_product;
        private System.Windows.Forms.DataGridView dGV_category;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBox_namaCategory;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tBox_nameProduct;
        private System.Windows.Forms.TextBox tBox_harga;
        private System.Windows.Forms.TextBox tBox_stock;
        private System.Windows.Forms.ComboBox cBox_chooseCategory;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.Button btn_showAll;
        private System.Windows.Forms.ComboBox cBox_filter;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

