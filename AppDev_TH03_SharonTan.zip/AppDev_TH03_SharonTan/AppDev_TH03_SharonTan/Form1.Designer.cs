﻿namespace AppDev_TH03_SharonTan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tBox_name = new System.Windows.Forms.TextBox();
            this.tBox_pass = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_regist = new System.Windows.Forms.Button();
            this.panel_regist = new System.Windows.Forms.Panel();
            this.btn_registNew = new System.Windows.Forms.Button();
            this.tBox_passRegist = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tBox_nameRegist = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_mainMenu = new System.Windows.Forms.Panel();
            this.panel_login = new System.Windows.Forms.Panel();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.lb_balance = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.lb_depo = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tBox_jmlhDepo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_depoMoney = new System.Windows.Forms.Button();
            this.btn_logOutDepo = new System.Windows.Forms.Button();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.lb_withdraw = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tBox_jmlhWithdraw = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_withdrawMoney = new System.Windows.Forms.Button();
            this.btn_logOutWith = new System.Windows.Forms.Button();
            this.panel_regist.SuspendLayout();
            this.panel_mainMenu.SuspendLayout();
            this.panel_login.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(228, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "UC BANK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(133, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(133, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // tBox_name
            // 
            this.tBox_name.Location = new System.Drawing.Point(252, 156);
            this.tBox_name.Name = "tBox_name";
            this.tBox_name.Size = new System.Drawing.Size(265, 31);
            this.tBox_name.TabIndex = 3;
            // 
            // tBox_pass
            // 
            this.tBox_pass.Location = new System.Drawing.Point(252, 220);
            this.tBox_pass.Name = "tBox_pass";
            this.tBox_pass.Size = new System.Drawing.Size(265, 31);
            this.tBox_pass.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(290, 300);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(119, 47);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_regist
            // 
            this.btn_regist.Location = new System.Drawing.Point(290, 369);
            this.btn_regist.Name = "btn_regist";
            this.btn_regist.Size = new System.Drawing.Size(119, 49);
            this.btn_regist.TabIndex = 6;
            this.btn_regist.Text = "Register";
            this.btn_regist.UseVisualStyleBackColor = true;
            this.btn_regist.Click += new System.EventHandler(this.btn_regist_Click);
            // 
            // panel_regist
            // 
            this.panel_regist.Controls.Add(this.btn_registNew);
            this.panel_regist.Controls.Add(this.tBox_passRegist);
            this.panel_regist.Controls.Add(this.label4);
            this.panel_regist.Controls.Add(this.tBox_nameRegist);
            this.panel_regist.Controls.Add(this.label5);
            this.panel_regist.Controls.Add(this.label6);
            this.panel_regist.Location = new System.Drawing.Point(39, 41);
            this.panel_regist.Name = "panel_regist";
            this.panel_regist.Size = new System.Drawing.Size(687, 489);
            this.panel_regist.TabIndex = 7;
            this.panel_regist.Visible = false;
            // 
            // btn_registNew
            // 
            this.btn_registNew.Location = new System.Drawing.Point(278, 300);
            this.btn_registNew.Name = "btn_registNew";
            this.btn_registNew.Size = new System.Drawing.Size(119, 50);
            this.btn_registNew.TabIndex = 12;
            this.btn_registNew.Text = "Register";
            this.btn_registNew.UseVisualStyleBackColor = true;
            this.btn_registNew.Click += new System.EventHandler(this.btn_registNew_Click);
            // 
            // tBox_passRegist
            // 
            this.tBox_passRegist.Location = new System.Drawing.Point(240, 222);
            this.tBox_passRegist.Name = "tBox_passRegist";
            this.tBox_passRegist.Size = new System.Drawing.Size(265, 31);
            this.tBox_passRegist.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(237, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 57);
            this.label4.TabIndex = 1;
            this.label4.Text = "UC BANK";
            // 
            // tBox_nameRegist
            // 
            this.tBox_nameRegist.Location = new System.Drawing.Point(240, 156);
            this.tBox_nameRegist.Name = "tBox_nameRegist";
            this.tBox_nameRegist.Size = new System.Drawing.Size(265, 31);
            this.tBox_nameRegist.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(121, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(121, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Username";
            // 
            // panel_mainMenu
            // 
            this.panel_mainMenu.Controls.Add(this.tBox_pass);
            this.panel_mainMenu.Controls.Add(this.label1);
            this.panel_mainMenu.Controls.Add(this.btn_regist);
            this.panel_mainMenu.Controls.Add(this.label2);
            this.panel_mainMenu.Controls.Add(this.btn_login);
            this.panel_mainMenu.Controls.Add(this.label3);
            this.panel_mainMenu.Controls.Add(this.tBox_name);
            this.panel_mainMenu.Location = new System.Drawing.Point(36, 38);
            this.panel_mainMenu.Name = "panel_mainMenu";
            this.panel_mainMenu.Size = new System.Drawing.Size(687, 489);
            this.panel_mainMenu.TabIndex = 13;
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.btn_withdraw);
            this.panel_login.Controls.Add(this.lb_balance);
            this.panel_login.Controls.Add(this.label7);
            this.panel_login.Controls.Add(this.btn_deposit);
            this.panel_login.Controls.Add(this.btn_logOut);
            this.panel_login.Controls.Add(this.label9);
            this.panel_login.Location = new System.Drawing.Point(33, 41);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(687, 489);
            this.panel_login.TabIndex = 14;
            this.panel_login.Visible = false;
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(278, 369);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(119, 49);
            this.btn_withdraw.TabIndex = 8;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(271, 208);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(30, 42);
            this.lb_balance.TabIndex = 7;
            this.lb_balance.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(228, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(227, 57);
            this.label7.TabIndex = 0;
            this.label7.Text = "UC BANK";
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(278, 298);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(119, 49);
            this.btn_deposit.TabIndex = 6;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_logOut
            // 
            this.btn_logOut.Location = new System.Drawing.Point(524, 32);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(119, 47);
            this.btn_logOut.TabIndex = 5;
            this.btn_logOut.Text = "Log Out";
            this.btn_logOut.UseVisualStyleBackColor = true;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(156, 219);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 25);
            this.label9.TabIndex = 2;
            this.label9.Text = "Balance";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.lb_depo);
            this.panel_deposit.Controls.Add(this.label11);
            this.panel_deposit.Controls.Add(this.label16);
            this.panel_deposit.Controls.Add(this.label8);
            this.panel_deposit.Controls.Add(this.tBox_jmlhDepo);
            this.panel_deposit.Controls.Add(this.label10);
            this.panel_deposit.Controls.Add(this.btn_depoMoney);
            this.panel_deposit.Controls.Add(this.btn_logOutDepo);
            this.panel_deposit.Location = new System.Drawing.Point(19, 44);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(687, 489);
            this.panel_deposit.TabIndex = 15;
            this.panel_deposit.Visible = false;
            this.panel_deposit.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_deposit_Paint);
            // 
            // lb_depo
            // 
            this.lb_depo.AutoSize = true;
            this.lb_depo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_depo.Location = new System.Drawing.Point(271, 181);
            this.lb_depo.Name = "lb_depo";
            this.lb_depo.Size = new System.Drawing.Size(30, 42);
            this.lb_depo.TabIndex = 10;
            this.lb_depo.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(163, 310);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 25);
            this.label11.TabIndex = 9;
            this.label11.Text = "Rp";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(156, 192);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 25);
            this.label16.TabIndex = 9;
            this.label16.Text = "Balance";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(232, 267);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(217, 25);
            this.label8.TabIndex = 9;
            this.label8.Text = "Input Deposit Amount";
            // 
            // tBox_jmlhDepo
            // 
            this.tBox_jmlhDepo.Location = new System.Drawing.Point(205, 307);
            this.tBox_jmlhDepo.Name = "tBox_jmlhDepo";
            this.tBox_jmlhDepo.Size = new System.Drawing.Size(265, 31);
            this.tBox_jmlhDepo.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(228, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(227, 57);
            this.label10.TabIndex = 0;
            this.label10.Text = "UC BANK";
            // 
            // btn_depoMoney
            // 
            this.btn_depoMoney.Location = new System.Drawing.Point(277, 373);
            this.btn_depoMoney.Name = "btn_depoMoney";
            this.btn_depoMoney.Size = new System.Drawing.Size(119, 49);
            this.btn_depoMoney.TabIndex = 6;
            this.btn_depoMoney.Text = "Deposit";
            this.btn_depoMoney.UseVisualStyleBackColor = true;
            this.btn_depoMoney.Click += new System.EventHandler(this.btn_depoMoney_Click);
            // 
            // btn_logOutDepo
            // 
            this.btn_logOutDepo.Location = new System.Drawing.Point(524, 32);
            this.btn_logOutDepo.Name = "btn_logOutDepo";
            this.btn_logOutDepo.Size = new System.Drawing.Size(119, 47);
            this.btn_logOutDepo.TabIndex = 5;
            this.btn_logOutDepo.Text = "Log Out";
            this.btn_logOutDepo.UseVisualStyleBackColor = true;
            this.btn_logOutDepo.Click += new System.EventHandler(this.btn_logOutDepo_Click);
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.lb_withdraw);
            this.panel_withdraw.Controls.Add(this.label12);
            this.panel_withdraw.Controls.Add(this.label17);
            this.panel_withdraw.Controls.Add(this.label13);
            this.panel_withdraw.Controls.Add(this.tBox_jmlhWithdraw);
            this.panel_withdraw.Controls.Add(this.label14);
            this.panel_withdraw.Controls.Add(this.btn_withdrawMoney);
            this.panel_withdraw.Controls.Add(this.btn_logOutWith);
            this.panel_withdraw.Location = new System.Drawing.Point(42, 35);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(687, 489);
            this.panel_withdraw.TabIndex = 16;
            this.panel_withdraw.Visible = false;
            // 
            // lb_withdraw
            // 
            this.lb_withdraw.AutoSize = true;
            this.lb_withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_withdraw.Location = new System.Drawing.Point(244, 181);
            this.lb_withdraw.Name = "lb_withdraw";
            this.lb_withdraw.Size = new System.Drawing.Size(30, 42);
            this.lb_withdraw.TabIndex = 12;
            this.lb_withdraw.Text = "-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(165, 310);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 25);
            this.label12.TabIndex = 9;
            this.label12.Text = "Rp";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(129, 192);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 25);
            this.label17.TabIndex = 11;
            this.label17.Text = "Balance";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(222, 267);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(233, 25);
            this.label13.TabIndex = 9;
            this.label13.Text = "Input Withdraw Amount";
            // 
            // tBox_jmlhWithdraw
            // 
            this.tBox_jmlhWithdraw.Location = new System.Drawing.Point(207, 307);
            this.tBox_jmlhWithdraw.Name = "tBox_jmlhWithdraw";
            this.tBox_jmlhWithdraw.Size = new System.Drawing.Size(265, 31);
            this.tBox_jmlhWithdraw.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei", 16.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(228, 68);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(227, 57);
            this.label14.TabIndex = 0;
            this.label14.Text = "UC BANK";
            // 
            // btn_withdrawMoney
            // 
            this.btn_withdrawMoney.Location = new System.Drawing.Point(279, 373);
            this.btn_withdrawMoney.Name = "btn_withdrawMoney";
            this.btn_withdrawMoney.Size = new System.Drawing.Size(119, 49);
            this.btn_withdrawMoney.TabIndex = 6;
            this.btn_withdrawMoney.Text = "Withdraw";
            this.btn_withdrawMoney.UseVisualStyleBackColor = true;
            this.btn_withdrawMoney.Click += new System.EventHandler(this.btn_withdrawMoney_Click);
            // 
            // btn_logOutWith
            // 
            this.btn_logOutWith.Location = new System.Drawing.Point(524, 32);
            this.btn_logOutWith.Name = "btn_logOutWith";
            this.btn_logOutWith.Size = new System.Drawing.Size(119, 47);
            this.btn_logOutWith.TabIndex = 5;
            this.btn_logOutWith.Text = "Log Out";
            this.btn_logOutWith.UseVisualStyleBackColor = true;
            this.btn_logOutWith.Click += new System.EventHandler(this.btn_logOutWith_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 569);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_mainMenu);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.panel_regist);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_regist.ResumeLayout(false);
            this.panel_regist.PerformLayout();
            this.panel_mainMenu.ResumeLayout(false);
            this.panel_mainMenu.PerformLayout();
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBox_name;
        private System.Windows.Forms.TextBox tBox_pass;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_regist;
        private System.Windows.Forms.Panel panel_regist;
        private System.Windows.Forms.Button btn_registNew;
        private System.Windows.Forms.TextBox tBox_passRegist;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBox_nameRegist;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel_mainMenu;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_depoMoney;
        private System.Windows.Forms.Button btn_logOutDepo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tBox_jmlhDepo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tBox_jmlhWithdraw;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btn_withdrawMoney;
        private System.Windows.Forms.Button btn_logOutWith;
        private System.Windows.Forms.Label lb_depo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lb_withdraw;
        private System.Windows.Forms.Label label17;
    }
}

