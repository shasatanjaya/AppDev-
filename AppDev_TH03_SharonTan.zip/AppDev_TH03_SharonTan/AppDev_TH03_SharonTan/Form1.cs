﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev_TH03_SharonTan
{
    public partial class Form1 : Form
    {
        CultureInfo culture = new CultureInfo("id-ID");
        List<string> listUsername = new List<string>();
        List<string> listPassword = new List<string>();
        List<int> listUang = new List<int>();

        int akunLogin = 0;
        int jumlahAkun = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            if (jumlahAkun == 0)
            {
                MessageBox.Show("Username and Password Not Found!");
                tBox_name.Clear();
                tBox_pass.Clear();
            }
            else
            {
                for (int i = 0; i < listUsername.Count; i++)
                {

                    if (tBox_name.Text == listUsername[i])
                    {
                        if (tBox_pass.Text == listPassword[i])
                        {
                            MessageBox.Show("Login Successful!");
                            akunLogin = i;
                            panel_login.Visible = true;
                            panel_mainMenu.Visible = false;
                            lb_balance.Text = listUang[akunLogin].ToString("C", culture);
                            lb_depo.Text = listUang[akunLogin].ToString("C", culture);
                            lb_withdraw.Text = listUang[akunLogin].ToString("C", culture);
                        }
                        else
                        {
                            MessageBox.Show("Username and Password Not Found!");
                        }
                    }
                    else
                    {
                        if (listUsername.Contains(tBox_name.Text))
                        {
                            //kalo ada biar lewat aja si, ga error message (i++)
                        }
                        else
                        {
                            MessageBox.Show("Username and Password Not Found!");
                        }

                    }
                }
                tBox_name.Clear();
                tBox_pass.Clear();
            }

        }

        private void btn_regist_Click(object sender, EventArgs e)
        {
            panel_regist.Visible = true;
            panel_mainMenu.Visible = false;
        }

        private void btn_registNew_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < listUsername.Count; i++) //ga ngecek pass krn tiap akun bisa punya pas yg sama ga si?
            {
                if (tBox_nameRegist.Text == listUsername[i])
                {
                    count++;
                }

            }

            if (count > 0)
            {
                MessageBox.Show("Username has been Used!");
                count = 0;
                tBox_nameRegist.Clear();
                tBox_passRegist.Clear();

            }
            else if (count == 0)
            {
                MessageBox.Show("Register Successful!");
                listUsername.Add(tBox_nameRegist.Text);
                listPassword.Add(tBox_passRegist.Text);
                listUang.Add(0);
                jumlahAkun++;
                tBox_nameRegist.Clear();
                tBox_passRegist.Clear();

                panel_regist.Visible = false;
                panel_mainMenu.Visible = true;
            }
        }
        private void btn_logOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Successfuly log out!");
            panel_login.Visible = false;
            panel_mainMenu.Visible = true;
        }
        private void btn_deposit_Click(object sender, EventArgs e)
        {
            panel_deposit.Visible = true;
            panel_login.Visible = false;
        }

        private void btn_depoMoney_Click(object sender, EventArgs e)
        {

            panel_deposit.Visible = true;
            int depomoney;
            depomoney = Convert.ToInt32(tBox_jmlhDepo.Text);

            if (depomoney > 0)
            {
                MessageBox.Show("Successfully add deposit!");
                listUang[akunLogin] += depomoney;
                lb_balance.Text = listUang[akunLogin].ToString("C", culture);
                lb_depo.Text = listUang[akunLogin].ToString("C", culture);
                lb_withdraw.Text = listUang[akunLogin].ToString("C", culture);
                tBox_jmlhDepo.Clear();
                panel_deposit.Visible = false;
                panel_login.Visible = true;

            }
            else if (depomoney <= 0)
            {
                MessageBox.Show("Deposit amount can't be less than one!");
                tBox_jmlhDepo.Clear();
                panel_deposit.Visible = false;
                panel_login.Visible = true;

            }
        }

        private void btn_withdrawMoney_Click(object sender, EventArgs e)
        {
            int withdrawal = Convert.ToInt32(tBox_jmlhWithdraw.Text);
            if (withdrawal <= listUang[akunLogin] && withdrawal > 0)
            {
                MessageBox.Show("Successfuly withdraw balance!");
                listUang[akunLogin] -= withdrawal;
                lb_balance.Text = listUang[akunLogin].ToString("C", culture);
                lb_depo.Text = listUang[akunLogin].ToString("C", culture);
                lb_withdraw.Text = listUang[akunLogin].ToString("C", culture);
                tBox_jmlhWithdraw.Clear();
                panel_withdraw.Visible = false;
                panel_login.Visible = true;

            }
            else if (withdrawal > listUang[akunLogin])
            {
                MessageBox.Show("Withdraw failed! Balance not enough!");
                tBox_jmlhWithdraw.Clear();
                panel_withdraw.Visible = false;
                panel_login.Visible = true;

            }
            else if (withdrawal <= 0)
            {
                MessageBox.Show("Withdraw failed! Can't withdraw less than one!");
                tBox_jmlhWithdraw.Clear();
                panel_withdraw.Visible = false;
                panel_login.Visible = true;
            }
        }

        private void btn_logOutDepo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Successfuly log out!");
            panel_deposit.Visible = false;
            panel_mainMenu.Visible = true;
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_withdraw.Visible = true;
        }

        private void btn_logOutWith_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Successfuly log out!");
            panel_withdraw.Visible = false;
            panel_mainMenu.Visible = true;
        }

        private void panel_deposit_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
