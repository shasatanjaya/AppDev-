﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev_TH04_Sharon_Tan
{
    internal class TeamClass
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<PlayerClass> listPlayer = new List<PlayerClass>();

        public TeamClass(string teamName, string teamCountry, string teamCity)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
        }

    }
}
