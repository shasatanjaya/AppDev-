﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev_TH04_Sharon_Tan
{
    internal class PlayerClass
    {
        public string playerName;
        public int playerNum;
        public string playerPos;

        public PlayerClass(string name, int num, string pos)
        {
            this.playerName = name;
            this.playerNum = num;
            this.playerPos = pos;
        }
    }

    
}
