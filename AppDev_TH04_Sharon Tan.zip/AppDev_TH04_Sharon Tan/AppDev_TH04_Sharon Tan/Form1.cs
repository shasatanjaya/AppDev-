﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace AppDev_TH04_Sharon_Tan
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        List<TeamClass> listTeam = new List<TeamClass>();

        private void Form1_Load(object sender, EventArgs e)
        {
            TeamClass team1 = new TeamClass("Manchester United", "England", "Machester");
            PlayerClass t1_p1 = new PlayerClass("David De Gea", 01, "GK");
            team1.listPlayer.Add(t1_p1);
            PlayerClass t1_p2 = new PlayerClass("Victor Lindelof", 02, "DF");
            team1.listPlayer.Add(t1_p2);
            PlayerClass t1_p3 = new PlayerClass("Phil Jones", 04, "DF");
            team1.listPlayer.Add(t1_p3);
            PlayerClass t1_p4 = new PlayerClass("Hary Maguire", 05, "DF");
            team1.listPlayer.Add(t1_p4);
            PlayerClass t1_p5 = new PlayerClass("Lisandro Martinez", 06, "DF");
            team1.listPlayer.Add(t1_p5);
            PlayerClass t1_p6 = new PlayerClass("Bruno Fernandez", 08, "MF");
            team1.listPlayer.Add(t1_p6);
            PlayerClass t1_p7 = new PlayerClass("Anthony Martial", 09, "FW");
            team1.listPlayer.Add(t1_p7);
            PlayerClass t1_p8 = new PlayerClass("Marcus Rashford", 10, "FW");
            team1.listPlayer.Add(t1_p8);
            PlayerClass t1_p9 = new PlayerClass("Tyrell Malacia", 12, "DF");
            team1.listPlayer.Add(t1_p9);
            PlayerClass t1_p10 = new PlayerClass("Christian Eriksen", 14, "MF");
            team1.listPlayer.Add(t1_p10);
            PlayerClass t1_p11 = new PlayerClass("Casemiro", 18, "MF");
            team1.listPlayer.Add(t1_p11);
            listTeam.Add(team1);

            TeamClass team2 = new TeamClass("Chelsea", "England", "London");
            PlayerClass t2_p1 = new PlayerClass("Kepa Arizabalaga", 01, "GK");
            team2.listPlayer.Add(t2_p1);
            PlayerClass t2_p2 = new PlayerClass("Benoît Badiashile", 04, "DF");
            team2.listPlayer.Add(t2_p2);
            PlayerClass t2_p3 = new PlayerClass("Enzo Fernández", 05, "MF");
            team2.listPlayer.Add(t2_p3);
            PlayerClass t2_p4 = new PlayerClass("Thiago Silva", 06, "DF");
            team2.listPlayer.Add(t2_p4);
            PlayerClass t2_p5 = new PlayerClass("N'Golo Kanté", 07, "MF");
            team2.listPlayer.Add(t2_p5);
            PlayerClass t2_p6 = new PlayerClass("Mateo Kovačić", 08, "MF");
            team2.listPlayer.Add(t2_p6);
            PlayerClass t2_p7 = new PlayerClass("Pierre-Emerick Aubameyang", 09, "FW");
            team2.listPlayer.Add(t2_p7);
            PlayerClass t2_p8 = new PlayerClass("Christian Pulisic", 10, "MF");
            team2.listPlayer.Add(t2_p8);
            PlayerClass t2_p9 = new PlayerClass("João Félix", 11, "FW");
            team2.listPlayer.Add(t2_p9);
            PlayerClass t2_p10 = new PlayerClass("Ruben Loftus-Cheek", 12, "MF");
            team2.listPlayer.Add(t2_p10);
            PlayerClass t2_p11 = new PlayerClass("Raheem Sterling", 17, "MF");
            team2.listPlayer.Add(t2_p11);
            listTeam.Add(team2);

            TeamClass team3 = new TeamClass("Bayem Munich", "Germany", "München");
            PlayerClass t3_p1 = new PlayerClass("Menuel Neuer", 01, "GK");
            team3.listPlayer.Add(t3_p1);
            PlayerClass t3_p2 = new PlayerClass("Dayot Upamecano", 02, "DF");
            team3.listPlayer.Add(t3_p2);
            PlayerClass t3_p3 = new PlayerClass("Matthijs de Ligt", 04, "DF");
            team3.listPlayer.Add(t3_p3);
            PlayerClass t3_p4 = new PlayerClass("Benjamin Pavard", 05, "DF");
            team3.listPlayer.Add(t3_p4);
            PlayerClass t3_p5 = new PlayerClass("Joshua Kimmich", 06, "MF");
            team3.listPlayer.Add(t3_p5);
            PlayerClass t3_p6 = new PlayerClass("Serge Gnarby", 07, "FW");
            team3.listPlayer.Add(t3_p6);
            PlayerClass t3_p7 = new PlayerClass("Leon Goretzka", 08, "MF");
            team3.listPlayer.Add(t3_p7);
            PlayerClass t3_p8 = new PlayerClass("Leroy Sané", 10, "FW");
            team3.listPlayer.Add(t3_p8);
            PlayerClass t3_p9 = new PlayerClass("Paul Wanner", 14, "MF");
            team3.listPlayer.Add(t3_p9);
            PlayerClass t3_p10 = new PlayerClass("Lucas Hernandes", 21, "DF");
            team3.listPlayer.Add(t3_p10);
            PlayerClass t3_p11 = new PlayerClass("Thomas Müller", 25, "FW");
            team3.listPlayer.Add(t3_p11);
            listTeam.Add(team3);
        }

        private void comBox_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            comBox_team.Items.Clear();
            ltBox_players.Items.Clear();
            foreach (TeamClass country in listTeam)
            {
                if (country.teamCountry == comBox_country.SelectedItem.ToString())
                {
                    comBox_team.Items.Add(country.teamName);
                }
            }

        }

        private void comBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            ltBox_players.Items.Clear();
            foreach (TeamClass team in listTeam)
            {
                if (team.teamName == comBox_team.SelectedItem.ToString())
                {
                    foreach (PlayerClass player in team.listPlayer)
                    {
                        if (player.playerNum < 10)
                        {
                            ltBox_players.Items.Add($"(0{player.playerNum}) {player.playerName}, {player.playerPos}");
                        }
                        else
                        {
                            ltBox_players.Items.Add($"({player.playerNum}) {player.playerName}, {player.playerPos}");
                        }
                    }
                }
            }
        }

        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            if (tBox_tName.Text == "" || tBox_tCountry.Text == "" || tBox_tCity.Text == "")
            {
                MessageBox.Show("All of The Fields Need To Be Filled!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int count = 0;
                bool sama = false;
                foreach (TeamClass team in listTeam)
                {
                    if (team.teamName.ToLower() == tBox_tName.Text.ToLower())
                    {
                        count++;
                    }
                }

                if (count > 0) //cek team double
                {
                    MessageBox.Show("Team Already Exist!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (count == 0)
                {
                    foreach (TeamClass team in listTeam) //cek country sama
                    {
                        if (team.teamCountry.Contains(tBox_tCountry.Text))
                        {
                            sama = true;
                        }
                    }

                    if (!sama) //kalo ga sama nambah baru
                    {
                        comBox_country.Items.Add(tBox_tCountry.Text);
                    }

                    TeamClass newTeam = new TeamClass(tBox_tName.Text, tBox_tCountry.Text, tBox_tCity.Text);
                    listTeam.Add(newTeam);
                }
            }
            tBox_tName.Clear();
            tBox_tCountry.Clear();
            tBox_tCity.Clear();

            comBox_team.Items.Clear(); //biar lansgung update directly
            foreach (TeamClass country in listTeam)
            {
                if (country.teamCountry == comBox_country.SelectedItem.ToString())
                {
                    comBox_team.Items.Add(country.teamName);
                }
            }
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (tBox_pName.Text == "" || tBox_pNumber.Text == "" || comBox_position.Text == "")
            {
                MessageBox.Show("All of The Fields Need To Be Filled!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string teamSelected = comBox_team.SelectedItem.ToString();

                foreach (TeamClass team in listTeam)
                {
                    if (team.teamName.Contains(teamSelected)) //ngatur team skrg adalah tim yg dipilih
                    {
                        foreach (PlayerClass player in team.listPlayer)
                        {
                            if (player.playerNum.ToString() == tBox_pNumber.Text) //cek player number double
                            {
                                count++;
                            }
                        }
                    }

                }

                if (count > 0)
                {
                    MessageBox.Show("Player with the same number is found!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (count == 0)
                {
                    PlayerClass newPlayer = new PlayerClass(tBox_pName.Text, Convert.ToInt32(tBox_pNumber.Text), comBox_position.SelectedItem.ToString());
                    if (newPlayer.playerNum < 10)
                    {
                        ltBox_players.Items.Add($"(0{newPlayer.playerNum}) {newPlayer.playerName}, {newPlayer.playerPos}");
                    }
                    else
                    {
                        ltBox_players.Items.Add($"({newPlayer.playerNum}) {newPlayer.playerName}, {newPlayer.playerPos}");
                    }

                    ltBox_players.Sorted = true;

                    foreach (TeamClass team in listTeam) //nambah player di tim yg dipilih
                    {
                        if (team.teamName.Contains(teamSelected))
                        {
                            team.listPlayer.Add(newPlayer);
                        }

                    }
                }
            }
            tBox_pName.Clear();
            tBox_pNumber.Clear();
            comBox_position.Text = "";
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (ltBox_players.Items.Count <= 11)
            {
                MessageBox.Show("Unable to remove players if players less than equal 11!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string teamSelected = comBox_team.SelectedItem.ToString();

                foreach (TeamClass team in listTeam)
                {
                    if (team.teamName.Contains(teamSelected)) //ngapus player di tim yg dipilih
                    {
                        team.listPlayer.RemoveAt(ltBox_players.SelectedIndex);
                    }
                }
                ltBox_players.Items.Remove(ltBox_players.SelectedItem);
            }
        }
    }
}
