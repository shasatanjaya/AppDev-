﻿namespace AppDev_TH04_Sharon_Tan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comBox_country = new System.Windows.Forms.ComboBox();
            this.comBox_team = new System.Windows.Forms.ComboBox();
            this.ltBox_players = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.tBox_tName = new System.Windows.Forms.TextBox();
            this.tBox_tCountry = new System.Windows.Forms.TextBox();
            this.tBox_tCity = new System.Windows.Forms.TextBox();
            this.tBox_pName = new System.Windows.Forms.TextBox();
            this.tBox_pNumber = new System.Windows.Forms.TextBox();
            this.comBox_position = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Team List:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Country:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Choose Team:";
            // 
            // comBox_country
            // 
            this.comBox_country.FormattingEnabled = true;
            this.comBox_country.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.comBox_country.Location = new System.Drawing.Point(241, 104);
            this.comBox_country.Name = "comBox_country";
            this.comBox_country.Size = new System.Drawing.Size(235, 33);
            this.comBox_country.TabIndex = 3;
            this.comBox_country.SelectedIndexChanged += new System.EventHandler(this.comBox_country_SelectedIndexChanged);
            // 
            // comBox_team
            // 
            this.comBox_team.FormattingEnabled = true;
            this.comBox_team.Location = new System.Drawing.Point(241, 152);
            this.comBox_team.Name = "comBox_team";
            this.comBox_team.Size = new System.Drawing.Size(235, 33);
            this.comBox_team.TabIndex = 4;
            this.comBox_team.SelectedIndexChanged += new System.EventHandler(this.comBox_team_SelectedIndexChanged);
            // 
            // ltBox_players
            // 
            this.ltBox_players.FormattingEnabled = true;
            this.ltBox_players.ItemHeight = 25;
            this.ltBox_players.Location = new System.Drawing.Point(43, 254);
            this.ltBox_players.Name = "ltBox_players";
            this.ltBox_players.Size = new System.Drawing.Size(433, 229);
            this.ltBox_players.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(641, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 31);
            this.label4.TabIndex = 6;
            this.label4.Text = "Adding Team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1117, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 31);
            this.label5.TabIndex = 7;
            this.label5.Text = "Adding Players";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(506, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Team Country:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(506, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Team Name:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(506, 207);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 25);
            this.label8.TabIndex = 12;
            this.label8.Text = "Team City:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(974, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(162, 25);
            this.label9.TabIndex = 18;
            this.label9.Text = "Player Position:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(974, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 25);
            this.label10.TabIndex = 15;
            this.label10.Text = "Player Number:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(974, 101);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 25);
            this.label11.TabIndex = 14;
            this.label11.Text = "Player Name:";
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Location = new System.Drawing.Point(668, 255);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(104, 43);
            this.btn_addTeam.TabIndex = 20;
            this.btn_addTeam.Text = "Add";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(42, 506);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(123, 40);
            this.btn_remove.TabIndex = 22;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Location = new System.Drawing.Point(1145, 254);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(104, 43);
            this.btn_addPlayer.TabIndex = 23;
            this.btn_addPlayer.Text = "Add";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // tBox_tName
            // 
            this.tBox_tName.Location = new System.Drawing.Point(665, 102);
            this.tBox_tName.Name = "tBox_tName";
            this.tBox_tName.Size = new System.Drawing.Size(250, 31);
            this.tBox_tName.TabIndex = 24;
            // 
            // tBox_tCountry
            // 
            this.tBox_tCountry.Location = new System.Drawing.Point(665, 150);
            this.tBox_tCountry.Name = "tBox_tCountry";
            this.tBox_tCountry.Size = new System.Drawing.Size(250, 31);
            this.tBox_tCountry.TabIndex = 25;
            // 
            // tBox_tCity
            // 
            this.tBox_tCity.Location = new System.Drawing.Point(665, 198);
            this.tBox_tCity.Name = "tBox_tCity";
            this.tBox_tCity.Size = new System.Drawing.Size(250, 31);
            this.tBox_tCity.TabIndex = 26;
            // 
            // tBox_pName
            // 
            this.tBox_pName.Location = new System.Drawing.Point(1142, 98);
            this.tBox_pName.Name = "tBox_pName";
            this.tBox_pName.Size = new System.Drawing.Size(248, 31);
            this.tBox_pName.TabIndex = 27;
            // 
            // tBox_pNumber
            // 
            this.tBox_pNumber.Location = new System.Drawing.Point(1140, 149);
            this.tBox_pNumber.Name = "tBox_pNumber";
            this.tBox_pNumber.Size = new System.Drawing.Size(250, 31);
            this.tBox_pNumber.TabIndex = 28;
            // 
            // comBox_position
            // 
            this.comBox_position.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.comBox_position.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.comBox_position.Location = new System.Drawing.Point(1138, 198);
            this.comBox_position.Name = "comBox_position";
            this.comBox_position.Size = new System.Drawing.Size(252, 33);
            this.comBox_position.TabIndex = 29;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1438, 583);
            this.Controls.Add(this.comBox_position);
            this.Controls.Add(this.tBox_pNumber);
            this.Controls.Add(this.tBox_pName);
            this.Controls.Add(this.tBox_tCity);
            this.Controls.Add(this.tBox_tCountry);
            this.Controls.Add(this.tBox_tName);
            this.Controls.Add(this.btn_addPlayer);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.btn_addTeam);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ltBox_players);
            this.Controls.Add(this.comBox_team);
            this.Controls.Add(this.comBox_country);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comBox_country;
        private System.Windows.Forms.ComboBox comBox_team;
        private System.Windows.Forms.ListBox ltBox_players;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button btn_addPlayer;
        private System.Windows.Forms.TextBox tBox_tName;
        private System.Windows.Forms.TextBox tBox_tCountry;
        private System.Windows.Forms.TextBox tBox_tCity;
        private System.Windows.Forms.TextBox tBox_pName;
        private System.Windows.Forms.TextBox tBox_pNumber;
        private System.Windows.Forms.ComboBox comBox_position;
    }
}

