﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Sharon_Tan
{
    public partial class Gameplay : Form
    {
        List<char> listHuruf = new List<char>();

        public Gameplay()
        {
            InitializeComponent();
            lbl_pilihanAkhir.Text = Form1.labelBawaan.ToUpper();

            foreach (char huruf in Form1.labelBawaan.ToUpper())
            {
                listHuruf.Add(huruf);
            }
            lbl_huruf1.Text = Convert.ToString(listHuruf[0]);
            lbl_huruf2.Text = Convert.ToString(listHuruf[1]);
            lbl_huruf3.Text = Convert.ToString(listHuruf[2]);
            lbl_huruf4.Text = Convert.ToString(listHuruf[3]);
            lbl_huruf5.Text = Convert.ToString(listHuruf[4]);
        }

        private void Gameplay_Load(object sender, EventArgs e) {}

        public void insertHuruf(char mencet) //method buat ngecek yg dipencet ama huruf
        {
            int count = 0;
            for (int i = 0; i < 5; i++)
            {
                if (mencet == listHuruf[i])
                {
                    count = i;
                    switch (count)
                    {
                        case 0:
                            lbl_strip1.Visible = false;
                            break;
                        case 1:
                            lbl_strip2.Visible = false;
                            break;
                        case 2:
                            lbl_strip3.Visible = false;
                            break;
                        case 3:
                            lbl_strip4.Visible = false;
                            break;
                        case 4:
                            lbl_strip5.Visible = false;
                            break;
                    }
                }
            }

            if (lbl_strip1.Visible == false && lbl_strip2.Visible == false && lbl_strip3.Visible == false && lbl_strip4.Visible == false && lbl_strip5.Visible == false)
            {
                MessageBox.Show("YOU WIN!!");
                new Form1().Show(); //Balik ke awal
                this.Hide(); //Menutup Gameplay
            }
        }

        private void btn_q_Click(object sender, EventArgs e)
        {
            insertHuruf('Q');
        }

        private void btn_w_Click(object sender, EventArgs e)
        {
            insertHuruf('W');
        }

        private void btn_e_Click(object sender, EventArgs e)
        {
            insertHuruf('E');
        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            insertHuruf('R');
        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            insertHuruf('T');
        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            insertHuruf('Y');
        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            insertHuruf('U');
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            insertHuruf('I');
        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            insertHuruf('O');
        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            insertHuruf('P');
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            insertHuruf('A');
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            insertHuruf('S');
        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            insertHuruf('D');
        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            insertHuruf('F');
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            insertHuruf('G');
        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            insertHuruf('H');
        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            insertHuruf('J');
        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            insertHuruf('K');
        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            insertHuruf('L');
        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            insertHuruf('Z');
        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            insertHuruf('X');
        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            insertHuruf('C');
        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            insertHuruf('V');
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            insertHuruf('B');
        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            insertHuruf('N');
        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            insertHuruf('M');
        }
    }
}
