﻿namespace TH02_Sharon_Tan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tBox_kata1 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.tBox_kata2 = new System.Windows.Forms.TextBox();
            this.tBox_kata3 = new System.Windows.Forms.TextBox();
            this.tBox_kata5 = new System.Windows.Forms.TextBox();
            this.tBox_kata4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(274, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kata 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(274, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kata 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(274, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Kata 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(274, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "Kata 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(274, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 31);
            this.label5.TabIndex = 4;
            this.label5.Text = "Kata 5";
            // 
            // tBox_kata1
            // 
            this.tBox_kata1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_kata1.Location = new System.Drawing.Point(401, 138);
            this.tBox_kata1.Name = "tBox_kata1";
            this.tBox_kata1.Size = new System.Drawing.Size(189, 35);
            this.tBox_kata1.TabIndex = 5;
            // 
            // btn_play
            // 
            this.btn_play.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_play.Location = new System.Drawing.Point(344, 386);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(155, 57);
            this.btn_play.TabIndex = 6;
            this.btn_play.Text = "Play";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // tBox_kata2
            // 
            this.tBox_kata2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_kata2.Location = new System.Drawing.Point(401, 182);
            this.tBox_kata2.Name = "tBox_kata2";
            this.tBox_kata2.Size = new System.Drawing.Size(189, 35);
            this.tBox_kata2.TabIndex = 7;
            // 
            // tBox_kata3
            // 
            this.tBox_kata3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_kata3.Location = new System.Drawing.Point(401, 225);
            this.tBox_kata3.Name = "tBox_kata3";
            this.tBox_kata3.Size = new System.Drawing.Size(189, 35);
            this.tBox_kata3.TabIndex = 8;
            // 
            // tBox_kata5
            // 
            this.tBox_kata5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_kata5.Location = new System.Drawing.Point(401, 313);
            this.tBox_kata5.Name = "tBox_kata5";
            this.tBox_kata5.Size = new System.Drawing.Size(189, 35);
            this.tBox_kata5.TabIndex = 10;
            // 
            // tBox_kata4
            // 
            this.tBox_kata4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBox_kata4.Location = new System.Drawing.Point(401, 269);
            this.tBox_kata4.Name = "tBox_kata4";
            this.tBox_kata4.Size = new System.Drawing.Size(189, 35);
            this.tBox_kata4.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("OCR A Extended", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(294, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(247, 39);
            this.label6.TabIndex = 11;
            this.label6.Text = "TEBAK KATA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 520);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tBox_kata5);
            this.Controls.Add(this.tBox_kata4);
            this.Controls.Add(this.tBox_kata3);
            this.Controls.Add(this.tBox_kata2);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.tBox_kata1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "HOMEPAGE TEBAK KATA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tBox_kata1;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.TextBox tBox_kata2;
        private System.Windows.Forms.TextBox tBox_kata3;
        private System.Windows.Forms.TextBox tBox_kata5;
        private System.Windows.Forms.TextBox tBox_kata4;
        private System.Windows.Forms.Label label6;
    }
}

