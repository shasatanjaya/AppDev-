﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Sharon_Tan
{

    public partial class Form1 : Form
    {
        public static string labelBawaan = ""; //ini buat bawa ke gameplay
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            List<string> listKata = new List<string>();

            if (tBox_kata1.Text.Length == 5 && tBox_kata2.Text.Length == 5 && tBox_kata3.Text.Length == 5 && tBox_kata4.Text.Length == 5 && tBox_kata5.Text.Length == 5) //cek panjang kata
            {
                int count = 0;
                int angka = 0;
                listKata.Add(tBox_kata1.Text);
                listKata.Add(tBox_kata2.Text);
                listKata.Add(tBox_kata3.Text);
                listKata.Add(tBox_kata4.Text);
                listKata.Add(tBox_kata5.Text);
                
                for (int i = 0; i < 5; i++) //cek angka
                {
                    if (listKata[i].Any(char.IsDigit))
                    {
                        angka++;
                    }
                }
                for (int i = 0; i < listKata.Count; i++) //cek double
                {
                    for (int j = 0; j < listKata.Count; j++)
                    {
                        if (listKata[i] == listKata[j])
                        {
                            count++;
                        }
                    }
                }

                if (angka > 0) //cek angka
                {
                    MessageBox.Show("Error! Kata memiliki angka!");
                }
                else if (count > 5) //cek count kata double, count harusnya = 5 baru bener
                {
                    MessageBox.Show("Error! Ada kata yang sama!");
                }
                else
                {
                    Random rnd = new Random();
                    int choosen = rnd.Next(0, 5);
                    labelBawaan = listKata[choosen]; //bawa ke Gameplay

                    new Gameplay().Show();
                    this.Hide(); //menutup form1
                }
            }
            else
            {
                MessageBox.Show("Error! Semua kata harus berisi 5 huruf!");
            }
        }
    }
}
